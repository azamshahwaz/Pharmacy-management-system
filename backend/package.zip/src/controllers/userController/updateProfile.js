import User from "../../models/User.js";

export const updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const { name, email, phone } = req.body;

    let updatedFields = [];
    let sameFields = [];

    // EMAIL CHECK
    if (email !== undefined) {
      const newEmail = email.trim();
      const currentEmail = user.email ? user.email.trim() : "";

      if (newEmail === currentEmail) {
        sameFields.push("Email");
      } else {
        const emailExists = await User.findOne({ email: newEmail });

        if (emailExists && emailExists._id.toString() !== user._id.toString()) {
          return res.status(400).json({ message: "Email already in use" });
        }

        user.email = newEmail;
        updatedFields.push("Email");
      }
    }

    // NAME CHECK
    if (name !== undefined) {
      const newName = name.trim();
      const currentName = user.name ? user.name.trim() : "";

      if (newName === currentName) {
        sameFields.push("Name");
      } else {
        user.name = newName;
        updatedFields.push("Name");
      }
    }

    // PHONE CHECK
    if (phone !== undefined) {
      const newPhone = String(phone).trim();
      const currentPhone = user.phone ? String(user.phone).trim() : "";

      if (newPhone === currentPhone) {
        sameFields.push("Phone");
      } else {
        const phoneExists = await User.findOne({ phone: newPhone });

        if (phoneExists && phoneExists._id.toString() !== user._id.toString()) {
          return res.status(400).json({ message: "Phone already in use" });
        }

        user.phone = newPhone;
        updatedFields.push("Phone");
      }
    }

    // SAVE ONLY IF UPDATED
    if (updatedFields.length > 0) {
      await user.save();
    }

    // REMOVE PASSWORD
    const userData = user.toObject();
    delete userData.password;

    // MESSAGE LOGIC
    let message = "";

    if (updatedFields.length === 0 && sameFields.length > 0) {
      message = "All fields are same";
    } 
    else if (updatedFields.length > 0 && sameFields.length === 0) {
      message = `${updatedFields.join(", ")} updated`;
    } 
    else if (updatedFields.length > 0 && sameFields.length > 0) {
      message = `${updatedFields.join(", ")} updated and ${sameFields.join(", ")} are same`;
    }

    res.json({
      message,
      user: userData
    });

  } catch (error) {
    console.error("Update Profile Error:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message
    });
  }
};
