import User from "../../models/User.js";
import bcrypt from "bcrypt";
import { validatePassword } from "../../utils/passwordValidator.js";

export const changePassword = async (req, res) => {
  try {
    console.log("URL hit:", req.originalUrl);
    const { currentPassword, newPassword } = req.body;

    // ✅ check fields
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        message: "Current password and new password are required"
      });
    }

    // ✅ validate new password
    if (!validatePassword(newPassword)) {
      return res.status(400).json({
        message:
          "Password must contain uppercase, lowercase, number & special character"
      });
    }

    // ✅ find user
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // ✅ match current password
    const isMatch = await bcrypt.compare(currentPassword, user.password);

    if (!isMatch) {
      return res.status(400).json({ message: "Current password incorrect" });
    }

    // ✅ prevent same password
    const isSamePassword = await bcrypt.compare(newPassword, user.password);

    if (isSamePassword) {
      return res.status(400).json({
        message: "New password cannot be same as current password"
      });
    }

    // ✅ update password
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    res.json({ message: "Password changed successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};



// Change Password
// export const changePassword = async (req, res) => {
//   try{
//     const { currentPassword, newPassword } = req.body;

//   if (!validatePassword(newPassword)) {
//     return res.status(400).json({
//       message:
//         "Password must contain uppercase, lowercase, number & special character",
//     });
//   }

//   const user = await User.findById(req.user.id);

//   const isMatch = await bcrypt.compare(currentPassword, user.password);

//   if (!isMatch) {
//     return res.status(400).json({ message: "Current password incorrect" });
//   }

//   const isSamePassword = await bcrypt.compare(newPassword, user.password);
//     if (isSamePassword) {
//       return res
//         .status(400)
//         .json({ message: "New password cannot be same as current password" });
//     }

//   user.password = await bcrypt.hash(newPassword, 10);
//   await user.save();

//   res.json({ message: "Password changed successfully" });
//  } catch (error) {
//   res.status(500).json({ message: "Server error" });
//   }
// };