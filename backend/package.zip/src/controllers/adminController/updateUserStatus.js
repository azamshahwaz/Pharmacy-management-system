import User from "../../models/User.js";

export const updateUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // ✅ status validation
    if (!["approved", "rejected"].includes(status)) {
      return res.status(400).json({
        message: "Status must be approved or rejected"
      });
    }

    const currentUser = req.user;

    const targetUser = await User.findById(id);

    if (!targetUser) {
      return res.status(404).json({
        message: "User not found"
      });
    }

    // ❌ self update block
    if (currentUser.id === id) {
      return res.status(400).json({
        message: "You cannot change your own status"
      });
    }

    // ❌ customer restriction
    if (currentUser.role === "customer") {
      return res.status(403).json({
        message: "Customer cannot approve or reject users"
      });
    }

    // ❌ staff restriction
    if (currentUser.role === "staff" && targetUser.role !== "customer") {
      return res.status(403).json({
        message: "Staff can only approve/reject customers"
      });
    }

    // ❌ admin protection
    if (targetUser.role === "admin") {
      return res.status(403).json({
        message: "Admin status cannot be changed"
      });
    }

    // ❌ same status check
    if (targetUser.status === status) {
      return res.status(400).json({
        message: `User is already ${status}`
      });
    }

    // ✅ update
    targetUser.status = status;
    await targetUser.save();

    res.status(200).json({
      message: `${targetUser.role} ${status} successfully`,
      user: targetUser
    });

  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};