import User from "../../models/User.js";

export const getAdmin = async (req, res) => {
  try {

    const admin = await User.findById(req.user.id).select("-password");

    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }

    res.json({
      message: "Welcome Admin!",
      admin
    });

  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};