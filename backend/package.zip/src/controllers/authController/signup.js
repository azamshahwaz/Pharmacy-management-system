import bcrypt from "bcrypt";
import { validatePassword, generateOTP } from "../../utils/passwordValidator.js";
import { sendOTPEmail } from "../../utils/sendMail.js";
import { tempUsers } from "../../utils/tempStore.js"; // ✅ FIX

export const signup = async (req, res) => {
  try {
    let { name, email, phone, password, role } = req.body;

    email = email?.toLowerCase().trim();
    phone = String(phone).trim();

    // ===== Required check =====
    if (!name || !email || !phone || !password || !role) {
      return res.status(400).json({ message: "All fields required" });
    }

    // ===== Email validation =====
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email))
      return res.status(400).json({ message: "Invalid email format" });

    // ===== Phone validation =====
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phone))
      return res.status(400).json({ message: "Invalid phone number" });

    // ===== Password validation =====
    if (!validatePassword(password)) {
      return res.status(400).json({ message: "Weak password" });
    }

    // ===== Generate OTP =====
    const otp = generateOTP();

    // ===== TEMP STORE =====
    tempUsers.set(email, {
      name,
      email,
      phone,
      password,
      role,
      otp,
      otpExpiry: Date.now() + 5 * 60 * 1000
    });

    await sendOTPEmail(email, otp);

    return res.status(200).json({
      message: "OTP sent. Please verify email"
    });

  } catch (error) {
    return res.status(500).json({
      message: "Server error",
      error: error.message
    });
  }
};