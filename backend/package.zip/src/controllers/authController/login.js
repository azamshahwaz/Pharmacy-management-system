import User from "../../models/User.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const login = async (req, res) => {
  try {
    const { email, phone, password } = req.body;

    // ==============================
    // ✅ Required Fields Check
    // ==============================
    if ((!email && !phone) || !password) {
      const missingFields = [];

      if (!email && !phone) missingFields.push("email or phone");
      if (!password) missingFields.push("password");

      return res.status(400).json({
        success: false,
        message: `Missing required field(s): ${missingFields.join(", ")}`
      });
    }

    // ==============================
    // ✅ Find User
    // ==============================
    const user = await User.findOne({
      $or: [{ email }, { phone }]
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid credentials"
      });
    }

    // ==============================
    // 🔒 CHECK ACCOUNT LOCK
    // ==============================
    if (user.lockUntil && user.lockUntil > Date.now()) {
      const remaining = Math.ceil((user.lockUntil - Date.now()) / 60000);

      return res.status(403).json({
        success: false,
        message: `Account locked. Try again in ${remaining} minutes`
      });
    }

    // ==============================
    // ✅ Password Match
    // ==============================
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {

      user.wrongPasswordAttempts += 1;

      // ❌ Lock after 5 attempts
      if (user.wrongPasswordAttempts >= 5) {
        user.lockUntil = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
      }

      await user.save();

      return res.status(400).json({
        success: false,
        message: "Wrong password"
      });
    }

    // ==============================
    // ✅ RESET ATTEMPTS (IMPORTANT)
    // ==============================
    user.wrongPasswordAttempts = 0;
    user.lockUntil = null;
    await user.save();

    // ==============================
    // ✅ Email Verification Check
    // ==============================
    if (!user.isVerified) {
      return res.status(403).json({
        success: false,
        message: "Please verify your email first"
      });
    }

    // ==============================
    // ✅ Approval Status Check
    // ==============================
    if (user.status === "pending") {
      return res.status(403).json({
        success: false,
        message: "Your account is not approved yet"
      });
    }

    if (user.status === "rejected") {
      return res.status(403).json({
        success: false,
        message: "Your account has been rejected"
      });
    }

    // ==============================
    // ✅ Generate JWT Token
    // ==============================
    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
        status: user.status
      },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    // ==============================
    // ✅ Final Response
    // ==============================
    res.status(200).json({
      success: true,
      message: `Welcome ${user.name}`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status
      }
    });

  } catch (error) {
    console.error("LOGIN ERROR:", error);
    res.status(500).json({
      success: false,
      message: "Server error"
    });
  }
};