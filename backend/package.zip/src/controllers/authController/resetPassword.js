import User from "../../models/User.js";
import bcrypt from "bcrypt";

export const resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    const user = await User.findOne({ email });

    // ✅ OTP Match
    if (!user || user.resetOTP?.toString() !== otp?.toString()) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // ✅ Expiry Check
    if (user.resetOTPExpire < Date.now()) {
      return res.status(400).json({ message: "OTP expired" });
    }

    // 🔒 NEW ≠ OLD password check
    const isSamePassword = await bcrypt.compare(newPassword, user.password);

    if (isSamePassword) {
      return res.status(400).json({
        message: "New password cannot be same as old password"
      });
    }

    // 🔐 Hash Password
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);

    // 🧹 Remove OTP after success
    user.resetOTP = undefined;
    user.resetOTPExpire = undefined;

    await user.save();

    res.json({ message: "Password reset successful" });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};