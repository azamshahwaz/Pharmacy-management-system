import User from "../../models/User.js";
import { generateOTP } from "../../utils/passwordValidator.js";
import { sendOTPEmail } from "../../utils/sendMail.js";

export const forgotPassword = async (req, res) => {
  try {
    let { email } = req.body;

    // ===== Normalize =====
    email = email?.toLowerCase().trim();

    // ===== Required check =====
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    // ===== Email format validation =====
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }

    // ===== Check user exists =====
    const user = await User.findOne({ email });

    // 🔒 Security: user exist ho ya na ho same response do
    if (!user) {
      return res.status(200).json({
        message: "If this email is registered, an OTP has been sent"
      });
    }

    // ===== Generate OTP =====
    const otp = generateOTP();

    user.resetOTP = otp;
    user.resetOTPExpire = Date.now() + 5 * 60 * 1000;

    await user.save();

    // ===== Send OTP =====
    try {
      await sendOTPEmail(email, otp);
    } catch (err) {
      return res.status(500).json({
        message: "Failed to send OTP. Try again later"
      });
    }

    // ===== Success =====
    return res.status(200).json({
      message: "If this email is registered, an OTP has been sent"
    });

  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Server error",
      error: error.message
    });
  }
};