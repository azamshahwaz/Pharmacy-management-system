import User from "../../models/User.js";
import bcrypt from "bcrypt";
import { tempUsers } from "../../utils/tempStore.js"; // ✅ FIX

export const verifyOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    // ===== get temp data =====
    const tempUser = tempUsers.get(email);

    if (!tempUser)
      return res.status(400).json({ message: "Signup expired. Try again" });

    // ===== OTP match =====
    if (String(tempUser.otp) !== String(otp))
      return res.status(400).json({ message: "Invalid OTP" });

    // ===== Expiry check =====
    if (Date.now() > tempUser.otpExpiry)
      return res.status(400).json({ message: "OTP expired" });

    // ===== Duplicate check =====
    const emailExists = await User.findOne({ email });
    const phoneExists = await User.findOne({ phone: tempUser.phone });

    if (emailExists)
      return res.status(400).json({ message: "Email already exists" });

    if (phoneExists)
      return res.status(400).json({ message: "Phone already exists" });

    // ===== Hash password =====
    const hashedPassword = await bcrypt.hash(tempUser.password, 10);

    // ===== Save user =====
    await User.create({
      name: tempUser.name,
      email: tempUser.email,
      phone: tempUser.phone,
      password: hashedPassword,
      role: tempUser.role,
      isVerified: true,
      status: tempUser.role === "admin" ? "approved" : "pending"
    });

    // ===== delete temp =====
    tempUsers.delete(email);

    return res.status(201).json({
      message: "Signup successful"
    });

  } catch (error) {
    return res.status(500).json({
      message: "Server error",
      error: error.message
    });
  }
};