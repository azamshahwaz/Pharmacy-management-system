import User from "../../models/User.js";

export const verifyResetOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    const user = await User.findOne({ email });

    console.log("User OTP:", user?.resetOTP);
    console.log("Entered OTP:", otp);

    // ===== OTP Match =====
    if (!user || user.resetOTP?.toString() !== otp?.toString()) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // ===== Expiry Check =====
    if (user.resetOTPExpire < Date.now()) {
      return res.status(400).json({ message: "OTP expired" });
    }

    return res.json({ message: "OTP verified" });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};