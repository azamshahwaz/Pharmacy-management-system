const Order = require("../models/order");
const Sale = require("../models/sale");

exports.acceptOrder = async (req, res) => {
  try {
    const orderId = req.params.id;

    // 1. Validate
    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required"
      });
    }

    // 2. Find Order
    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    // 3. Prevent duplicate sale ❗
    if (order.status === "confirmed") {
      return res.status(400).json({
        success: false,
        message: "Order already accepted"
      });
    }

    // 4. Update order status
    order.status = "confirmed";
    await order.save();

    // 5. Proper mapping (IMPORTANT 🔥)
    const saleItems = order.items.map(item => ({
      medicine: item.medicine,
      quantity: item.quantity,
      price: item.price,
      discount: item.discount || 0,
      total: item.quantity * item.price
    }));

    // 6. Total calculate
    const totalAmount = saleItems.reduce((sum, i) => sum + i.total, 0);

    // 7. Create Sale (schema ke hisaab se)
    const sale = await Sale.create({
      customer: order.user, // agar user field hai
      items: saleItems,
      totalAmount,
      paymentMethod: order.paymentMethod,
      paymentStatus: "pending",
      orderStatus: "accepted",
      acceptedby: req.user ? req.user.id : null
    });

    // 8. Response
    return res.status(200).json({
      success: true,
      message: "Order accepted & Sale created successfully",
      data: {
        order,
        sale
      }
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};