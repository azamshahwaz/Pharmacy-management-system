import Order from "../models/Order.js";
import Batch from "../models/medicinebatch.js";
import Medicine from "../models/Medicine.js";

export const placeOrder = async (req, res) => {
  try {
    const userId = req.user.id;
    const { items, address, paymentMethod } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ message: "No items in order" });
    }

    let orderItems = [];
    let totalAmount = 0;

    for (let item of items) {
      const { medicineId, quantity } = item;

      // ✅ Step 1: Medicine check
      const medicine = await Medicine.findById(medicineId);
      if (!medicine) {
        return res.status(404).json({ message: "Medicine not found" });
      }

      // ✅ Step 2: Batch fetch (FIFO - expiry wise)
      const batches = await Batch.find({
        medicine: medicineId,
        quantity: { $gt: 0 }
      }).sort({ expiryDate: 1 });

      let qtyNeeded = quantity;

      // ✅ Step 3: Deduct from batches
      for (let batch of batches) {
        if (qtyNeeded <= 0) break;

        const deductQty = Math.min(batch.quantity, qtyNeeded);

        batch.quantity -= deductQty;
        await batch.save();

        orderItems.push({
          medicine: medicineId,
          batch: batch._id,
          quantity: deductQty,
          price: batch.sellingPrice,
          purchasePrice: batch.purchasePrice
        });

        totalAmount += deductQty * batch.sellingPrice;
        qtyNeeded -= deductQty;
      }

      // ❌ Stock not enough
      if (qtyNeeded > 0) {
        return res.status(400).json({ message: "Not enough stock" });
      }
    }

    // ✅ Step 4: Create order
    const order = await Order.create({
      user: userId,
      items: orderItems,
      totalAmount,
      address,
      paymentMethod,
      status: "pending",
      paymentStatus: "pending"
    });

    return res.status(201).json({
      message: "Order placed successfully",
      order
    });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};