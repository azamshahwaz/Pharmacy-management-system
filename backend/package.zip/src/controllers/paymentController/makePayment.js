import Payment from "../../models/payment.js";
import Sale from "../../models/sale.js";

const makePayment = async (req, res) => {
  try {
    const { saleId, amount, method } = req.body;

    // 1. Validation
    if (!saleId || !amount || !method) {
      return res.status(400).json({
        success: false,
        message: "Sale ID, amount and method are required"
      });
    }

    // 2. Check Sale
    const sale = await Sale.findById(saleId);

    if (!sale) {
      return res.status(404).json({
        success: false,
        message: "Sale not found"
      });
    }

    // 3. Calculate total paid already
    const payments = await Payment.find({ sale: saleId });

    const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);

    const newTotalPaid = totalPaid + amount;

    // 4. Decide status
    let status = "due";

    if (newTotalPaid >= sale.totalAmount) {
      status = "paid";
    } else if (newTotalPaid > 0) {
      status = "partial";
    }

    // 5. Create Payment
    const payment = await Payment.create({
      sale: saleId,
      amount,
      method,
      status,
      paidAt: new Date()
    });

    // 6. Update Sale
    sale.paymentStatus = status;
    await sale.save();

    // 7. Response
    return res.status(200).json({
      success: true,
      message: "Payment recorded successfully",
      data: {
        payment,
        totalPaid: newTotalPaid,
        remaining: sale.totalAmount - newTotalPaid,
        saleStatus: status
      }
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};

export default makePayment;