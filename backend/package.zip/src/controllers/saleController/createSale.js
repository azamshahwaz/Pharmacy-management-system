import Sale from "../models/Sale.js";

const generateBillNumber = () => {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `INV-${year}${month}${day}-${hours}${minutes}${seconds}`;
};

export const createSale = async (req, res) => {
  try {
    const { customer, items, paymentMethod } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ message: "No items provided" });
    }

    let totalAmount = 0;

    const saleItems = items.map(item => {
      const { medicine, quantity, price, discount = 0 } = item;

      const totalPrice = price * quantity;
      const discountAmount = (totalPrice * discount) / 100;
      const itemTotal = totalPrice - discountAmount;

      totalAmount += itemTotal;

      return {
        medicine,
        quantity,
        price,
        discount,
        total: itemTotal
      };
    });

    const billNumber = generateBillNumber();

    const sale = await Sale.create({
      customer,
      items: saleItems,
      totalAmount,
      paymentMethod,
      billNumber,
      acceptedby: req.user?._id
    });

    return res.status(201).json({
      message: "Sale created successfully",
      sale
    });

  } catch (error) {
    return res.status(500).json({
      message: "Error creating sale",
      error: error.message
    });
  }
};