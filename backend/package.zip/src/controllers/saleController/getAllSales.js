// GET /sales
import Sale from "../models/sale.js";

export const getAllSales = async (req, res) => {
  try {
    const sales = await Sale.find()
      .populate("customer", "name")
      .populate("items.medicine", "name")
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: sales.length,
      data: sales
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message
    });
  }
};