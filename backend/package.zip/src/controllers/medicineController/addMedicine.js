import Medicine from "../../models/medicine.js";

const addMedicine = async (req, res) => {
  try {
    // 1. Empty body check
    if (!req.body || Object.keys(req.body).length === 0) {
      return res.status(400).json({
        success: false,
        message: "No data provided"
      });
    }

    // 2. Create medicine
    const medicine = await Medicine.create(req.body);

    // 3. Success response
    return res.status(201).json({
      success: true,
      message: "Medicine added successfully",
      data: medicine
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};

export default addMedicine;