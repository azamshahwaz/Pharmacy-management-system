import Order from "../../models/order.js";
import Sale from "../../models/sale.js";

const acceptOrder = async (req, res) => {
  try {
    const { id } = req.params;

    // 1. Check ID
    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Order ID is required"
      });
    }

    // 2. Find Order
    const order = await Order.findById(id);

    // 3. Not found
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    // 4. Update status
    order.status = "confirmed";
    await order.save();

    // 5. Calculate total
    let totalAmount = 0;
    order.items.forEach(item => {
      totalAmount += item.quantity * item.price; // ⚠️ ensure price exists
    });

    // 6. Create Sale
    const sale = await Sale.create({
      items: order.items,
      totalAmount,
      paymentStatus: "pending"
    });

    // 7. Success response
    return res.status(200).json({
      success: true,
      message: "Order accepted & Sale created successfully",
      data: {
        order,
        sale
      }
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};

export default acceptOrder;