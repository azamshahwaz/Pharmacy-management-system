import Medicine from "../../models/medicine.js";

const deleteMedicine = async (req, res) => {
  try {
    const { id } = req.params;

    // 1. Check ID
    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Medicine ID is required"
      });
    }

    // 2. Delete medicine
    const medicine = await Medicine.findByIdAndDelete(id);

    // 3. Not found
    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found"
      });
    }

    // 4. Success response
    return res.status(200).json({
      success: true,
      message: "Medicine deleted successfully",
      data: medicine   // optional (frontend ko useful hota hai)
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};

export default deleteMedicine;