import Medicine from "../../models/medicine.js";

const getAllMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find()
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: medicines.length,
      data: medicines
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};

export default getAllMedicines;