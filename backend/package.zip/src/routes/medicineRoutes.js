import { addMedicine, fetchMedicine, updateMedicine, deleteMedicine  } from "../controllers/medicineController/index.js";



router.post("/add", addMedicine);
router.get("/", getAllMedicines);
router.put("/:id", updateMedicine);
router.delete("/:id", deleteMedicine);

module.exports = router;