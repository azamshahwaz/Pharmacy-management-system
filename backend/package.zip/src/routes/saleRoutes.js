import express from "express";
import { getAllSales } from "../controllers/saleController.js";

const router = express.Router();

router.get("/sales", getAllSales);

export default router;