import express from "express";
import { protect } from "../middleware/authMiddleware.js";

import {
  getProfile,
  updateProfile,
  changePassword
} from "../controllers/userController/index.js";

const router = express.Router();

router.get("/profile", protect, getProfile);
router.put("/update-profile", protect, updateProfile);
router.put("/change-password", protect, changePassword);

export default router;