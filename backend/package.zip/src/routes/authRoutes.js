import express from "express";
import { signup, login, verifyOTP, resendOTP, forgotPassword, verifyResetOTP, resetPassword } from "../controllers/authController/index.js";
import { loginLimiter } from "../middleware/rateLimiter.js";

const router = express.Router();

// Auth routes
router.post("/signup", signup);
router.post("/login", loginLimiter, login);

// OTP routes
router.post("/verify-otp", verifyOTP);
router.post("/resend-otp", resendOTP);

// Password reset routes
router.post("/forgot-password", forgotPassword);
router.post("/verify-reset-otp", verifyResetOTP);
router.post("/reset-password", resetPassword);


export default router;

