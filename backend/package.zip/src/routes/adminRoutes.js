import express from "express";
const router = express.Router();

import { protect } from "../middleware/authMiddleware.js";
import { authorizeRoles } from "../middleware/roleMiddleware.js";

import {
  getAdmin,
  getAllUsers,
  deleteUser,
  updateUserStatus
} from "../controllers/adminController/index.js";

router.get("/admin", protect, authorizeRoles("admin"), getAdmin);
router.get("/users", protect, authorizeRoles("admin"), getAllUsers);
router.delete("/users/:id", protect, authorizeRoles("admin"), deleteUser);

router.put(
  "/status/:id",
  protect,
  authorizeRoles("admin", "staff"),
  updateUserStatus
);

export default router;