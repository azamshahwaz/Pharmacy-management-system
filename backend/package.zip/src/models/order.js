const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },
  items: [
    {
      medicine: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Medicine"
      },
      quantity: Number
    }
  ],
  address: String,
  status: {
    type: String,
    enum: ["pending", "confirmed", "delivered"],
    default: "pending"
  },
  paymentMethod: String
}, { timestamps: true });

module.exports = mongoose.model("Order", orderSchema);