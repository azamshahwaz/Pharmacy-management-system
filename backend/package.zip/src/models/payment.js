const paymentSchema = new mongoose.Schema({
  sale: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Sale",
    required: true
  },

  amount: Number,

  method: {
    type: String,
    enum: ["cash", "upi", "card"]
  },

  status: {
    type: String,
    enum: ["paid", "partial", "due"]
  },

  paidAt: Date
});