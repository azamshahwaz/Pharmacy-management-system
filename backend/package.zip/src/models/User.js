import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: String,

    email: {
      type: String,
      unique: true,
      required: true
    },

    phone: {
      type: Number,
      unique: true,
      required: true
    },

    password: {
      type: String,
      required: true
    },

    role: {
      type: String,
      enum: ["admin", "staff", "customer"],
      default: "customer"
    },

    status: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending"
    },

    isVerified: {
      type: Boolean,
      default: false
    },

    // Signup OTP
    otp: Number,
    otpExpiry: Date,

    // 🔐 Reset Password OTP
    resetOTP: String,
    resetOTPExpire: Date,

    // 🔒 LOGIN SECURITY
    wrongPasswordAttempts: {
      type: Number,
      default: 0
    },

    lockUntil: {
      type: Date,
      default: null
    }
  },
  { timestamps: true }
);

const User = mongoose.model("User", userSchema);

export default User;