import mongoose from "mongoose";

const medicineSchema = new mongoose.Schema(
  {
    productName: {
      type: String,
      required: true,
      trim: true
    },
    
    manufacturer: {
      type: String
    },

    productCategory: {
      type: String,
      enum: ["tablet", "syrup", "injection", "ointment", "capsule", "drop", "other"],
      required: true
    },

  },
  { timestamps: true }
);

export default mongoose.model("Medicine", medicineSchema);