import nodemailer from "nodemailer";

export const sendOTPEmail = async (email, otp) => {
  try {

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Verify Your Email – OTP Valid for 5 Minutes",
      text: `Dear User,

Thank you for signing up with us!
 
To complete your registration, please verify your email address using the OTP provided below. 

Your One-Time Password (OTP) for verification is: 

OTP: ${otp}

This OTP is valid for the next 5 minutes. Please do not share this OTP with anyone for security reasons.

If you did not sign up for an account, please ignore this email.

Best regards,
New Drug Team`
    });

  } catch (error) {
    console.log("MAIL ERROR:", error); // IMPORTANT
    throw new Error("Failed to send OTP");
  }
};