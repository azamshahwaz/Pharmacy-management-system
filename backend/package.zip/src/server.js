import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { connectDB } from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import { getAllsales } from "../../controllers/saleController/index.js";


dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
// Middleware
app.use(express.json()); // this middleware will parse JSON bodies: req.body
// app.use(rateLimiter);

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);

app.use("/api", saleRoutes);

connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    }); 
})

// console.log(process.env.MONGO_URI); // Debugging line to check if MONGO_URI is loaded
// console.log("JWT_SECRET:", process.env.JWT_SECRET); // Check if JWT_SECRET is loaded correctly